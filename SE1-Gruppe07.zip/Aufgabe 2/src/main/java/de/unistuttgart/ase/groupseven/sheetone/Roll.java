// Maximilian Peresunchak (st152466@stud.uni-stuttgart.de)
// Nico Reng (st188620@stud.uni-stuttgart.de)
// Viorel Tsigos (st188085@stud.uni-stuttgart.de)
// Philip Reimann (st182312@stud.uni-stuttgart.de)
// Christian Keller (st166512@stud.uni-stuttgart.de)
// Johannes Heugel (st183360@stud.uni-stuttgart.de)
// Benedikt Wachmer (st177118@stud.uni-stuttgart.de)
// Miles Holl (st180549@stud.uni-stuttgart.de)

package de.unistuttgart.ase.groupseven.sheetone;

/**
 * Immutable value object representing a single roll in the bowling game.
 *
 * @param pins the number of pins knocked down in this roll (0-{@link Frame#MAX_PINS})
 */
public record Roll(int pins) {}
