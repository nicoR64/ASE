// Maximilian Peresunchak (st152466@stud.uni-stuttgart.de)
// Nico Reng (st188620@stud.uni-stuttgart.de)
// Viorel Tsigos (st188085@stud.uni-stuttgart.de)
// Philip Reimann (st182312@stud.uni-stuttgart.de)
// Christian Keller (st166512@stud.uni-stuttgart.de)

package de.unistuttgart.ase.groupseven.sheetone;

public record Roll(int pins) {}
